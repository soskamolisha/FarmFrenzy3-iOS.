import XCTest
@testable import FarmFrenzyRecovery

final class LevelCatalogTests: XCTestCase {
    func testParsesBasicLevel() throws {
        let xml = #"<Levels><Level Name="1" StartMoney="100" GoldTime="60" SilverTime="120"><Goals><g Type="EGG" Val="6"/></Goals></Level></Levels>"#
        let result = try LevelCatalog().parse(data: Data(xml.utf8))
        XCTAssertEqual(result.count, 1)
        XCTAssertEqual(result[0].name, "1")
        XCTAssertEqual(result[0].startMoney, 100)
        XCTAssertEqual(result[0].goals, [LevelGoal(type: "EGG", value: 6)])
    }
}
