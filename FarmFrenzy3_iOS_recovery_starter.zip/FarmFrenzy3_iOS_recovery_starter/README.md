# Farm Frenzy 3 — iOS recovery starter

This repository is a clean starting point for investigating a user-owned copy of the original Farm Frenzy 3 iOS app and prototyping a modern 64-bit replacement runtime.

## Important technical finding

The original app executable is **32-bit ARM only (ARMv6/ARMv7)**. It has no ARM64 slice. Modern iOS releases do not run 32-bit iOS apps, so changing `MinimumOSVersion`, renaming files, or re-signing the IPA cannot make the original binary compatible.

The original resource archives (`data.pack` and `data.pack_hd`) were inspected. Both are valid ZIP archives containing XML game configuration/levels, PNG/PVR textures, texture-atlas metadata, WAV audio, and font resources.

## Project boundary

- Keep the original IPA and its assets private; do not commit them to a public repository.
- This repository contains only analysis metadata and a small Swift parsing prototype.
- A compatible app requires a new ARM64 runtime and recreation of the game systems. This is not a simple binary patch and cannot be promised as a quick rebuild.
- Only use game files you are authorized to use. Do not distribute extracted proprietary assets.

## First milestone

Parse `levels.xml` from an extracted resource pack and expose a level catalog. Then incrementally prototype the game state and rendering layer while preserving the original assets locally.

## Build

The Swift package can be tested on a Mac with Swift installed. A cloud CI runner can run tests, but it does not remove the need to implement the replacement runtime.

```sh
swift test
```

## iPhone-only workflow

You can create a GitHub repository in Safari and upload this starter ZIP through GitHub's web interface. GitHub Actions can run the package tests in the cloud. Actual iOS app signing and device installation will require an appropriate Apple development/signing workflow.
