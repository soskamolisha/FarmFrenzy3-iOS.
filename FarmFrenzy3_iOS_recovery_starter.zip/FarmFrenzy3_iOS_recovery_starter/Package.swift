// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "FarmFrenzyRecovery",
    platforms: [.iOS(.v15), .macOS(.v12)],
    products: [
        .library(name: "FarmFrenzyRecovery", targets: ["FarmFrenzyRecovery"])
    ],
    targets: [
        .target(name: "FarmFrenzyRecovery"),
        .testTarget(name: "FarmFrenzyRecoveryTests", dependencies: ["FarmFrenzyRecovery"])
    ]
)
