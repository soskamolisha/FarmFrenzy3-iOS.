import Foundation
#if canImport(FoundationXML)
import FoundationXML
#endif

public struct LevelGoal: Equatable {
    public let type: String
    public let value: Int
}

public struct LevelDefinition: Equatable {
    public let name: String
    public let startMoney: Int
    public let goldTime: Double
    public let silverTime: Double
    public let goals: [LevelGoal]
}

/// Reads the original game's XML level format.
/// Pass the contents of levels.xml from a legally obtained resource archive.
public final class LevelCatalog: NSObject, XMLParserDelegate {
    private var levels: [LevelDefinition] = []
    private var currentName = ""
    private var currentMoney = 0
    private var currentGold = 0.0
    private var currentSilver = 0.0
    private var currentGoals: [LevelGoal] = []
    private var insideLevel = false

    public func parse(data: Data) throws -> [LevelDefinition] {
        levels.removeAll()
        let parser = XMLParser(data: data)
        parser.delegate = self
        guard parser.parse() else {
            throw parser.parserError ?? NSError(
                domain: "FarmFrenzyRecovery.LevelCatalog",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "Could not parse levels.xml"]
            )
        }
        return levels
    }

    public func parser(_ parser: XMLParser,
                       didStartElement elementName: String,
                       namespaceURI: String?,
                       qualifiedName qName: String?,
                       attributes attributeDict: [String: String]) {
        if elementName == "Level" {
            insideLevel = true
            currentName = attributeDict["Name"] ?? ""
            currentMoney = Int(attributeDict["StartMoney"] ?? "0") ?? 0
            currentGold = Double(attributeDict["GoldTime"] ?? "0") ?? 0
            currentSilver = Double(attributeDict["SilverTime"] ?? "0") ?? 0
            currentGoals = []
        } else if elementName == "g", insideLevel,
                  let type = attributeDict["Type"] {
            let value = Int(attributeDict["Val"] ?? "0") ?? 0
            currentGoals.append(LevelGoal(type: type, value: value))
        }
    }

    public func parser(_ parser: XMLParser,
                       didEndElement elementName: String,
                       namespaceURI: String?,
                       qualifiedName qName: String?) {
        if elementName == "Level", insideLevel {
            levels.append(LevelDefinition(
                name: currentName,
                startMoney: currentMoney,
                goldTime: currentGold,
                silverTime: currentSilver,
                goals: currentGoals
            ))
            insideLevel = false
        }
    }
}
